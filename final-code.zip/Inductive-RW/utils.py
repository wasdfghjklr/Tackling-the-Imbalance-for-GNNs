import torch
from torch.autograd import Variable
import math
import numpy as np
from sklearn import metrics
from miner import noi_sampling, uni_sampling, noi_sampling_1, noi_sampling_2, noi_sampling_3
import time
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import f1_score, accuracy_score
from sklearn.metrics import confusion_matrix
from numpy import *

#from numpy import *


def f(max_epoch, epoch, eps):
    f_value = 1/2*math.cos(epoch*math.pi/max_epoch) + 1/2 + eps
    return f_value


def euclidian_distance(x, y):
    return torch.sqrt(torch.sum((x - y) ** 2))


def sampl_lst(data, sample_ratio, mode, traindata_hardpoint_list):
    uni_sampling_list = uni_sampling(data, sample_ratio)

    if mode == 1:
        # only class  mix1
        noi_sampling_list = noi_sampling(data, sample_ratio)[0]
    elif mode == 2:
        # class * node  mix2
        noi_sampling_list = noi_sampling_1(
            data, sample_ratio, traindata_hardpoint_list)
    elif mode == 3:
        # only node
        noi_sampling_list = noi_sampling_3(
            data, sample_ratio, traindata_hardpoint_list)
    else:
        # class + node mix3
        target_num_list = noi_sampling(data, sample_ratio)[1]
        noi_sampling_list = noi_sampling_2(
            data, sample_ratio, target_num_list, traindata_hardpoint_list)

    return uni_sampling_list, noi_sampling_list


def train(net, optimizer, data, epoch, max_epoch, criterion2, weights, mode, traindata_hardpoint_list):
    net.train()
    optimizer.zero_grad()
    labels_origin = list(range(int(data.y.max()) + 1))
    labels = data.y

    output_pred_, _ = net(data.x, data.adj)

    noi_labels_ = labels

    loss = criterion2(output_pred_, noi_labels_)
    loss_ours = my_loss(output_pred_, noi_labels_, labels_origin, weights)
    loss_focal = focal_loss(output_pred_,noi_labels_,weights)

    acc = accuracy(output_pred_, noi_labels_)

    # micro_f1_noi = microF1(output_pred_, noi_labels_)
    # macro_f1_noi = macroF1(output_pred_, noi_labels_)

    # micro_f1 = micro_f1_noi
    # macro_f1 = macro_f1_noi

    macrof1_train = macrof1(output_pred_, data.y)
    gmean_train = g_mean(output_pred_, data.y)

    loss_focal.backward()
    optimizer.step()
    return loss, acc, macrof1_train, gmean_train


def val(net, data, criterion2, alpha):

    net.eval()
    output_noi_logit, _ = net(data.x, data.adj)  
    labels = data.y

    # output_combin = torch.tensor(
    #     [1-alpha] * len(labels)).view(-1, 1).to('cpu') * output_noi_logit
    output_combin = torch.tensor(
        [1-alpha] * len(labels)).view(-1, 1) * output_noi_logit

    output_pred_ = output_combin
    noi_labels_ = labels

    loss_val = criterion2(output_pred_, noi_labels_)

    acc_val = accuracy(output_pred_, noi_labels_)

    # micro_f1_noi = microF1(output_pred_, noi_labels_)
    # macro_f1_noi = macroF1(output_pred_, noi_labels_)

    # micro_f1_val = micro_f1_noi
    # macro_f1_val = macro_f1_noi

    macrof1_val = macrof1(output_pred_, data.y)
    gmean_val = g_mean(output_pred_, data.y)

    return loss_val, acc_val, macrof1_val, gmean_val


def test(net, data, criterion2, alpha):
    net.eval()
    output_noi, _ = net(data.x, data.adj)
    labels = data.y

    # output_combin = torch.tensor(
    #     [1-alpha] * len(labels)).view(-1, 1).to('cpu') * output_noi_logit
    output_combin = torch.tensor(
        [1-alpha] * len(labels)).view(-1, 1) * output_noi

    output_pred_ = output_combin
    noi_labels_ = labels

    loss_test = criterion2(output_pred_, noi_labels_)
    acc_test = accuracy(output_pred_, noi_labels_)

    # micro_f1_noi = microF1(output_pred_, noi_labels_)
    # macro_f1_noi = macroF1(output_pred_, noi_labels_)

    # micro_f1_test = micro_f1_noi
    # macro_f1_test = macro_f1_noi

    macrof1_test = macrof1(output_pred_, data.y)
    gmean_test = g_mean(output_pred_, data.y)

    return loss_test, acc_test, macrof1_test, gmean_test


def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    # correct = preds.eq(labels).double()
    # correct = correct.sum()
    acc = accuracy_score(labels, preds)
    # return correct / len(labels)
    return acc


def microF1(output, labels):
    y_pred = output.max(1)[1].cpu().numpy()
    y_true = labels.cpu().numpy()
    return metrics.f1_score(y_true, y_pred, average='micro')

# reweight


def my_loss(outputs, y_true, labels, weights):
    probability = F.softmax(outputs, dim=1)  # shape [num_samples,num_classes]

    log_P = torch.log(probability)
    # one_hot = torch.zeros(probability.shape, dtype=float).to(
    #     device='cpu').scatter_(1, torch.unsqueeze(y_true, dim=1), 1)
    one_hot = torch.zeros(probability.shape, dtype=float).to(
        device='cpu').scatter_(1, torch.unsqueeze(y_true, dim=1), 1)
    loss3 = 0

    for i in range(probability.shape[0]):
        loss3 -= one_hot[i]*log_P[i] * weights[i]
    loss3 = loss3.sum()

    return loss3

def focal_loss(outputs, y_true, weights):
    probability = F.softmax(outputs, dim=1)  # shape [num_samples,num_classes]
    log_P = torch.log(probability)
    # one_hot = torch.zeros(probability.shape, dtype=float).to(
    #     device='cpu').scatter_(1, torch.unsqueeze(y_true, dim=1), 1)
    one_hot = torch.zeros(probability.shape, dtype=float).to(
        device='cpu').scatter_(1, torch.unsqueeze(y_true, dim=1), 1)
    loss3 = 0
    dic_sum_prob = {}
    dic_label_coun = {}
    weight_fl = {}
    for i in range(probability.shape[1]):
        dic_sum_prob[i] = 0
        dic_label_coun[i] = 0
        weight_fl[i] = 0           
    for j in range(probability.shape[0]):
        dic_sum_prob[y_true[j].detach().cpu().numpy().tolist()] += probability[j][y_true[j]].detach().cpu().numpy().tolist()
        dic_label_coun[y_true[j].detach().cpu().numpy().tolist()] += 1
    for k in weight_fl:
        if dic_label_coun[k] == 0:
            weight_fl[k] = 0
        else:
            weight_fl[k] = dic_sum_prob[k]/dic_label_coun[k]
    for i in range(probability.shape[0]):
        loss3 -= one_hot[i] * log_P[i] * weights[i] * math.pow((1-weight_fl[y_true[i].detach().cpu().numpy().tolist()]),2)
    loss3 = loss3.sum()
    return loss3

def macrof1(output, labels):
    preds = output.max(1)[1].type_as(labels)
    return f1_score(labels, preds, average='macro')


def g_mean(output, labels):
    preds = output.max(1)[1].type_as(labels)
    # precision = metrics.precision_score(labels, preds, average = 'macro')
    n = int(max(labels)+1)
    specificity = spe(labels,preds,n)
    print(specificity)
    recall = metrics.recall_score(labels, preds, average = 'macro')
    return math.sqrt(specificity * recall)

def dic_acc_lable(net, data):
    net.eval()
    output, _ = net(data.x, data.adj)
    # print(len(output))
    labels = data.y.cpu().numpy().tolist()
    preds = output.max(1)[1].type_as(data.y)
    dic_acc = {}
    dic_lable = {}
    for i, e in enumerate(labels):
        if e in dic_lable:  
            dic_lable[e] += 1
            if e == preds[i]: 
                if e in dic_acc:
                    dic_acc[e] += 1  
                else:
                    dic_acc[e] = 1
        else:  
            dic_lable[e] = 1
            if e == preds[i]: 
                if e in dic_acc:
                    dic_acc[e] += 1 
                else:
                    dic_acc[e] = 1
    return dic_acc, dic_lable, labels, preds

def spe(Y_test,Y_pred,n):
    
    spe = []
    con_mat = confusion_matrix(Y_test,Y_pred)
    for i in range(n):
        number = np.sum(con_mat[:,:])
        tp = con_mat[i][i]
        fn = np.sum(con_mat[i,:]) - tp
        fp = np.sum(con_mat[:,i]) - tp    
        tn = number - tp - fn - fp
        spe1 = tn / (tn + fp)
        spe.append(spe1)
    speci = mean(spe)
    return speci