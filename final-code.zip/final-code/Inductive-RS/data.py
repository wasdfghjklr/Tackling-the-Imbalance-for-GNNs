import torch
import os
import numpy as np
import scipy.sparse as sp
import torch_geometric.datasets as geo_data
import random
# import Dataset

DATA_ROOT = 'data'
if not os.path.isdir(DATA_ROOT):
    os.mkdir(DATA_ROOT)


# def load_data_adj(data_name='cora', normalize_feature=True, missing_rate=0, cuda=False):
#     # can use other dataset, some doesn't have mask
#     data = geo_data.Planetoid(os.path.join(DATA_ROOT, data_name), data_name).data
#     # data = geo_data.Coauthor(os.path.join(
#     #     DATA_ROOT, data_name), data_name).data
#     # original split
#     data.train_mask = data.train_mask.type(torch.bool)
#     data.val_mask = data.val_mask.type(torch.bool)
#     # data.test_mask = data.test_mask.type(torch.bool)
#     # expand test_mask to all rest nodes
#     data.test_mask = ~(data.train_mask + data.val_mask)
#     # get adjacency matrix
#     n = len(data.x)
#     adj = sp.csr_matrix(
#         (np.ones(data.edge_index.shape[1]), data.edge_index), shape=(n, n))
#     return adj


class Partitioned_Data():
    def __init__(self, size, hidden, max_edge):
        super(Partitioned_Data, self).__init__()
        self.x = torch.Tensor((size, hidden))
        self.y = torch.Tensor(size)
        self.edge_index = torch.Tensor((2, max_edge))
        self.edge_attr = None
        self.pos = None
        self.norm = None
        self.face = None
        self.adj = None

    def __getitem__(self, idx):
        x_i = self.x[idx]
        y_i = self.y[idx]
        edge_index_i = self.edge_index[idx]
        sample = {'x_i': x_i, 'y_i': y_i, 'edge_index_i': edge_index_i}


def partition(data, ratio):
    n = len(data.y)
    m = data.edge_index.size(1)
    train_num = int(n * ratio[0] / 10)
    val_num = int(n * ratio[1] / 10)
    test_num = n - train_num - val_num
    edge_num = data.edge_index.size(1)
    hidden_dim = data.x.size(1)
    train_data = Partitioned_Data(train_num, hidden_dim, edge_num)
    val_data = Partitioned_Data(val_num, hidden_dim, edge_num)
    test_data = Partitioned_Data(test_num, hidden_dim, edge_num)

    train_data.x = data.x[:train_num]
    train_data.y = data.y[:train_num]
    val_data.x = data.x[train_num:train_num+val_num]
    val_data.y = data.y[train_num:train_num+val_num]
    test_data.x = data.x[n-test_num:]
    test_data.y = data.y[n-test_num:]

    train_edge_l = []
    val_edge_l = []
    test_edge_l = []

    for i in range(m):
        if data.edge_index[0, i] < train_num and data.edge_index[1, i] < train_num:
            train_edge_l.append(data.edge_index[:, i].tolist())
        elif (train_num <= data.edge_index[0, i] < train_num+val_num) and (train_num <= data.edge_index[1, i] < train_num+val_num):
            data.edge_index[:, i] -= train_num
            val_edge_l.append(data.edge_index[:, i].tolist())
        elif data.edge_index[0, i] >= n-test_num and data.edge_index[1, i] >= n-test_num:
            data.edge_index[:, i] -= (train_num+val_num)
            test_edge_l.append(data.edge_index[:, i].tolist())
        else:
            continue
#     print(train_edge_l)
    train_data.edge_index = torch.tensor(train_edge_l).permute(1, 0)
    val_data.edge_index = torch.tensor(val_edge_l).permute(1, 0)
    test_data.edge_index = torch.tensor(test_edge_l).permute(1, 0)

    return train_data, val_data, test_data


def get_adjacency(data, data_name='cora', normalize_feature=True, missing_rate=0, cuda=False):
    n = len(data.x)
    print("number")
    print(n)
    adj = sp.csr_matrix(
        (np.ones(data.edge_index.shape[1]), data.edge_index), shape=(n, n))
#    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj) + sp.eye(adj.shape[0])
    adj = adj + adj.T.multiply(adj.T > adj) - \
        adj.multiply(adj.T > adj) + 1*sp.eye(adj.shape[0])
    # symmetric normalization works bad, but why? Test more.
    adj = normalize_adj_row(adj)
    data.adj = to_torch_sparse(adj)
    # normalize feature
    if normalize_feature:
        data.x = row_l1_normalize(data.x)

    # generate missing feature setting
    indices_dir = os.path.join(DATA_ROOT, data_name, 'indices')
    if not os.path.isdir(indices_dir):
        os.mkdir(indices_dir)
    missing_indices_file = os.path.join(
        indices_dir, "indices_missing_rate={}.npy".format(missing_rate))
    if not os.path.exists(missing_indices_file):

        erasing_pool = torch.arange(n)
        size = int(len(erasing_pool) * (missing_rate/100))
        idx_erased = np.random.choice(erasing_pool, size=size, replace=False)
        np.save(missing_indices_file, idx_erased)
        pass
    else:
        idx_erased = np.load(missing_indices_file)
    # erasing feature for random missing
    if missing_rate > 0:
        data.x[idx_erased] = 0

    if cuda:
        data.x = data.x.cuda()
        data.y = data.y.cuda()
        data.adj = data.adj.cuda()

    return data


def load_data(data_name='cora', normalize_feature=True, missing_rate=0, cuda=False):
    # can use other dataset, some doesn't have mask
    data = geo_data.Planetoid(os.path.join(DATA_ROOT, data_name), data_name).data
    # data = geo_data.Coauthor(os.path.join(DATA_ROOT, data_name), data_name).data

# if shuffle, run the following block
    # n = len(data.y)
    # m = data.edge_index.size(1)
    # data_idx = list(range(n))
    # random.seed(1421)
    # random.shuffle(data_idx)
    # #print('data_idx:',data_idx)
    # print('data_idx:',len(data_idx))
    # data.x = data.x[data_idx]
    # data.y = data.y[data_idx]
    # for i in range(m):
    #     j = data.edge_index[0,i]
    #     data.edge_index[0,i] = data_idx[j]
    #     k = data.edge_index[1,i]
    #     data.edge_index[1,i] = data_idx[k]

    p_train_data, p_val_data, p_test_data = partition(data, [0.3,0.97,8.73])

    # get adjacency matrix
    train_data = get_adjacency(
        p_train_data, data_name, normalize_feature, missing_rate, cuda)
    val_data = get_adjacency(p_val_data, data_name,
                             normalize_feature, missing_rate, cuda)
    test_data = get_adjacency(p_test_data, data_name,
                              normalize_feature, missing_rate, cuda)

    return train_data, val_data, test_data


def normalize_adj(adj):
    """Symmetrically normalize adjacency matrix."""
    # add self-loop and normalization also affects performance a lot
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()


def normalize_adj_row(adj):
    """Row-normalize sparse matrix"""
    rowsum = np.array(adj.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(adj)
    return mx


def to_torch_sparse(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)


def row_l1_normalize(X):
    norm = 1e-6 + X.sum(dim=1, keepdim=True)
    return X/norm


if __name__ == "__main__":
    import sys
    print(sys.version)
    # test goes here
#     data = load_data(cuda=True)
    train_data, val_data, test_data = load_data(cuda=True)
#     data, adj_origin = load_data(cuda=True)
#     print(data.train_mask[:150])
#     print(adj_origin)
#     print(get_graph_distance(2,332,adj_origin.indices,adj_origin.indptr))
