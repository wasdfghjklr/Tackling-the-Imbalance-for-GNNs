import torch
import numpy as np
from collections import Counter
import torch.nn.functional as F
from torch.utils.data.sampler import WeightedRandomSampler
from torch.utils.data import DataLoader
import time


def euclidian_distance(x, y):
    return torch.sqrt(torch.sum((x - y) ** 2))


def uni_sampling(data, sample_ratio):
    label = data.y
    train_index_list = list(range(len(data.y)))  # index?是顺序列表？
    uniform_list = list(range(int(sample_ratio*len(data.y))))
    anchor_label_list = []
    anchor_index_list = []
    for anchor_index in train_index_list:
        anchor_index_list.append(anchor_index)
        anchor_label_list.append(int(label[anchor_index].cpu().numpy()))
    dataset = list(zip(anchor_index_list, anchor_label_list))

    uniform_weight_1 = [1] * len(uniform_list)
    sampler = WeightedRandomSampler(uniform_weight_1,
                                    num_samples=int(len(uniform_list)),
                                    replacement=False)
    dataloader = DataLoader(dataset,
                            batch_size=int(
                                len(anchor_index_list) * sample_ratio),
                            sampler=sampler)
    for anchor_index_list, labels in dataloader:
        uniform_list = anchor_index_list
    return uniform_list


def noi_sampling(data, sample_ratio):
    '''
    noi_sampling on class
    '''
    label = data.y

    noiform_list = list(range(int(sample_ratio*len(data.y))))
    train_index_list = list(range(len(data.y)))

    anchor_label_list = []
    anchor_index_list = []
    for anchor_index in train_index_list:
        anchor_index_list.append(anchor_index)
        anchor_label_list.append(int(label[anchor_index].cpu().numpy()))
    dataset = list(zip(anchor_index_list, anchor_label_list))
    data_summery = [anchor_label_list.count(
        i) for i in range(int(data.y.max()) + 1)]
    sum_count = sum(data_summery)
    data_prob_dist = [sum_count / i for i in data_summery]
    weights = []
    for i, label in enumerate(anchor_label_list):
        weights.append(data_prob_dist[label])
    sampler = WeightedRandomSampler(weights,
                                    num_samples=int(
                                        len(anchor_index_list) * sample_ratio),
                                    replacement=True)
    dataloader = DataLoader(dataset,
                            batch_size=int(
                                len(anchor_index_list) * sample_ratio),
                            sampler=sampler)
    for anchor_index_list, labels in dataloader:
        noiform_list = anchor_index_list
        label_list = labels

    counts = Counter(label_list.cpu().numpy().tolist())
    target_num_list = [counts[i] for i in range(int(data.y.max()) + 1)]

    return noiform_list, target_num_list


def noi_sampling_1(data, sample_ratio, traindata_hardpoint_list):
    '''
    noi_sampling on class*node
    '''
    label = data.y
    adj = data.adj

    noiform_list = list(range(int(sample_ratio*len(data.y))))
    train_index_list = list(range(len(data.y)))

    anchor_label_list = []
    anchor_index_list = []
    for anchor_index in train_index_list:
        anchor_index_list.append(anchor_index)
        anchor_label_list.append(int(label[anchor_index].cpu().numpy()))
    dataset = list(zip(anchor_index_list, anchor_label_list))
    anchor_summery = [anchor_label_list.count(
        i) for i in range(int(data.y.max()) + 1)]

    anchor_hardpoint_list = traindata_hardpoint_list

    sum_count = sum(anchor_summery)
    data_prob_dist = [sum_count / i for i in anchor_summery]
    weights = []
    for i, label in enumerate(anchor_label_list):
        weights.append(data_prob_dist[label] *
                       torch.exp(anchor_hardpoint_list[i]))
    sampler = WeightedRandomSampler(weights,
                                    num_samples=int(
                                        len(anchor_index_list) * sample_ratio),
                                    replacement=True)
    dataloader = DataLoader(dataset,
                            batch_size=int(
                                len(anchor_index_list) * sample_ratio),
                            sampler=sampler)
    for anchor_index_list, labels in dataloader:
        noiform_list = anchor_index_list

    return noiform_list


def noi_sampling_2(data, sample_ratio, target_num_list, traindata_hardpoint_list):
    '''
    class + node
    '''
    label = data.y
    noiform_list = []

#    noiform_list = list(range(int(sample_ratio*len(data.y))))
    train_index_list = list(range(len(data.y)))

    dis_smooth_idx = traindata_hardpoint_list  # [每个idx对应的指数]

    anchor_label_list = []
    anchor_index_list = []
    for anchor_index in train_index_list:
        anchor_index_list.append(anchor_index)  # [index]
        anchor_label_list.append(
            int(label[anchor_index].cpu().numpy()))  # [每个idx对应的label]

    # dic label idx
    dic_label_idx = {}  
    for i in range(int(data.y.max()) + 1):
        dic_label_idx[i] = []
    # dic label weight
    dic_label_smoothness = {}  
    for i in range(int(data.y.max()) + 1):
        dic_label_smoothness[i] = []
    for i, each_label in enumerate(anchor_label_list):
        dic_label_idx[each_label].append(anchor_index_list[i])
        dic_label_smoothness[each_label].append(dis_smooth_idx[i])
    for i in range(int(data.y.max()) + 1):
        cur_list = []
        weights = []
        for _, w in enumerate(dic_label_smoothness[i]):
            weights.append(torch.exp(w))
        dataset = list(zip(dic_label_idx[i], [i] * len(dic_label_idx[i])))
        sampler = WeightedRandomSampler(weights,
                                        num_samples=target_num_list[i],
                                        replacement=True)
        dataloader = DataLoader(dataset,
                                batch_size=target_num_list[i],
                                sampler=sampler)
        for anchor_index_list, labels in dataloader:
            cur_list = anchor_index_list
        noiform_list += cur_list
    noiform_list = torch.tensor(noiform_list)
    return noiform_list


def noi_sampling_3(data, sample_ratio, traindata_hardpoint_list):
    '''
    noi_sampling on node LDS
    '''
    label = data.y
    adj = data.adj

    noiform_list = list(range(int(sample_ratio*len(data.y))))
    train_index_list = list(range(len(data.y)))

    anchor_label_list = []
    anchor_index_list = []
    for anchor_index in train_index_list:
        anchor_index_list.append(anchor_index)
        anchor_label_list.append(int(label[anchor_index].cpu().numpy()))
    dataset = list(zip(anchor_index_list, anchor_label_list))
    anchor_summery = [anchor_label_list.count(
        i) for i in range(int(data.y.max()) + 1)]

    anchor_hardpoint_list = traindata_hardpoint_list

    data_prob_dist = [1 for i in anchor_summery]
    weights = []
    for i, label in enumerate(anchor_label_list):
        weights.append(data_prob_dist[label] *
                       torch.exp(anchor_hardpoint_list[i]))
    sampler = WeightedRandomSampler(weights,
                                    num_samples=int(
                                        len(anchor_index_list) * sample_ratio),
                                    replacement=True)
    dataloader = DataLoader(dataset,
                            batch_size=int(
                                len(anchor_index_list) * sample_ratio),
                            sampler=sampler)
    for anchor_index_list, labels in dataloader:
        noiform_list = anchor_index_list

    return noiform_list
