import torch, os
import numpy as np 
import scipy.sparse as sp
import torch_geometric.datasets as geo_data
import random
# import Dataset
import torch.nn.functional as F

DATA_ROOT = 'data'
if not os.path.isdir(DATA_ROOT):
    os.mkdir(DATA_ROOT)
    
# def node_nbhd(v, indices, indptr):
#     '''
#     给定一个节点v，该函数返回其所有邻居节点以及节点v的deg
#     '''
#     #print('indptr:',indptr[v + 1], ' ', indptr[v])
#     if indptr[v + 1] - indptr[v] > 0:
#         deg_v = indptr[v + 1] - indptr[v]
#         root_nbhd = []
#         u0 = indices[indptr[v]]
#         root_nbhd.append(u0)
#         r = 1
#         while r < deg_v:
#             u1 = indices[indptr[v + 1] - deg_v + r]
#             root_nbhd.append(u1)
#             r = r + 1
#         assert deg_v == len(root_nbhd)
#         return root_nbhd
#     else:
#         return None

# def get_graph_distance(v1,v2,indices,indptr):
#     '''
#     give node v1,v2, return dist between v1,v2 in terms of graph with threshold 3
#     '''
    
#     v1_nbhd = node_nbhd(v1, indices, indptr)
#     print(v1_nbhd)
#     if v2 in v1_nbhd:
#         k = 1
#         return k
#     else:
#         for nodes in v1_nbhd:
#             if v2 in node_nbhd(nodes,indices,indptr):
#                 k = 2
#                 return k
#             else:
#                 for node_nb in node_nbhd(nodes,indices,indptr):
#                     if v2 in node_nbhd(node_nb,indices,indptr):
#                         k = 3
#                         return k
#                     else:
#                         return 10
     

# def load_data_adj(data_name='cora', normalize_feature=True, missing_rate=0, cuda=False):
#     # can use other dataset, some doesn't have mask
#     data = geo_data.Planetoid(os.path.join(DATA_ROOT, data_name), data_name).data 
#     # data = geo_data.Coauthor(os.path.join(DATA_ROOT, data_name), data_name).data
#     # original split
#     data.train_mask = data.train_mask.type(torch.bool)
#     data.val_mask = data.val_mask.type(torch.bool)
#     # data.test_mask = data.test_mask.type(torch.bool)    
#     # expand test_mask to all rest nodes 
#     data.test_mask = ~(data.train_mask + data.val_mask)
#     # get adjacency matrix
#     n = len(data.x)
#     adj = sp.csr_matrix((np.ones(data.edge_index.shape[1]), data.edge_index), shape=(n,n))
#     return adj

class Partitioned_Data():
    def __init__(self, size, hidden, max_edge):
        super(Partitioned_Data, self).__init__()
        self.x = torch.Tensor((size, hidden))
        self.y = torch.Tensor(size)
        self.edge_index = torch.Tensor((2, max_edge))
        self.edge_attr = None
        self.pos = None
        self.norm = None
        self.face = None
        self.adj = None
    def __getitem__(self, idx):
        x_i = self.x[idx]
        y_i = self.y[idx]
        edge_index_i = self.edge_index[idx]
        sample = {'x_i': x_i, 'y_i': y_i, 'edge_index_i': edge_index_i}
        

def partition(data, ratio):
    n = len(data.y)
    m = data.edge_index.size(1)
    train_num = int(n * ratio[0] / 10)
    val_num = int(n * ratio[1] / 10)
    test_num = n - train_num - val_num
    edge_num = data.edge_index.size(1)
    hidden_dim = data.x.size(1)
    train_data = Partitioned_Data(train_num, hidden_dim, edge_num)
    val_data = Partitioned_Data(val_num, hidden_dim, edge_num)
    test_data = Partitioned_Data(test_num, hidden_dim, edge_num)
    
    train_data.x = data.x[:train_num]
    train_data.y = data.y[:train_num]
    val_data.x = data.x[train_num:train_num+val_num]
    val_data.y = data.y[train_num:train_num+val_num]
    test_data.x = data.x[n-test_num:]
    test_data.y = data.y[n-test_num:]
    
    train_edge_l = []
    val_edge_l = []
    test_edge_l = []
    
    for i in range(m):
        if data.edge_index[0,i] < train_num and data.edge_index[1,i] < train_num:
            train_edge_l.append(data.edge_index[:,i].tolist())
        elif (train_num <= data.edge_index[0,i] < train_num+val_num) and (train_num <= data.edge_index[1,i] < train_num+val_num):
            data.edge_index[:,i] -= train_num
            val_edge_l.append(data.edge_index[:,i].tolist())
        elif data.edge_index[0,i] >= n-test_num and data.edge_index[1,i] >= n-test_num:
            data.edge_index[:,i] -= (train_num+val_num)
            test_edge_l.append(data.edge_index[:,i].tolist())
        else:
            continue
#     print(train_edge_l)
    train_data.edge_index = torch.tensor(train_edge_l).permute(1,0)
    val_data.edge_index = torch.tensor(val_edge_l).permute(1,0)
    test_data.edge_index = torch.tensor(test_edge_l).permute(1,0)
    
    return train_data, val_data, test_data

def partition_two(data, data_idx, ratio):
    n = len(data.y)
    m = data.edge_index.size(1)
    train_num = int(n * ratio[0] / 10)
    test_num = n - train_num
    edge_num = data.edge_index.size(1)
    hidden_dim = data.x.size(1)
    train_data = Partitioned_Data(train_num, hidden_dim, edge_num)
    test_data = Partitioned_Data(test_num, hidden_dim, edge_num)
    
    train_data.x = data.x[:train_num]
    train_data.y = data.y[:train_num]
    test_data.x = data.x[n-test_num:]
    test_data.y = data.y[n-test_num:]
    
    train_edge_l = []
    test_edge_l = []
    
    for i in range(m):
        if data.edge_index[0,i] < train_num and data.edge_index[1,i] < train_num:
            train_edge_l.append(data.edge_index[:,i].tolist())
        elif data.edge_index[0,i] >= n-train_num and data.edge_index[1,i] >= n-train_num:
            data.edge_index[:,i] -= (train_num)
            test_edge_l.append(data.edge_index[:,i].tolist())
        else:
            continue
#     print(train_edge_l)
    train_data.edge_index = torch.tensor(train_edge_l).permute(1,0)
    test_data.edge_index = torch.tensor(test_edge_l).permute(1,0)
    
    return train_data, test_data, train_num, test_num

def get_adjacency(data, data_name='cora', normalize_feature=True, missing_rate=0, cuda=False):
    n = len(data.x)
    print("number")
    print(n)
    adj = sp.csr_matrix((np.ones(data.edge_index.shape[1]), data.edge_index), shape=(n,n))
#    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj) + sp.eye(adj.shape[0])
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj) + 1*sp.eye(adj.shape[0])
    adj = normalize_adj_row(adj) # symmetric normalization works bad, but why? Test more. 
    data.adj = to_torch_sparse(adj)
    # normalize feature
    if normalize_feature:
        data.x = row_l1_normalize(data.x)
    
    # generate missing feature setting 
    indices_dir = os.path.join(DATA_ROOT, data_name, 'indices')
    if not os.path.isdir(indices_dir): 
        os.mkdir(indices_dir)
    missing_indices_file = os.path.join(indices_dir, "indices_missing_rate={}.npy".format(missing_rate))
    if not os.path.exists(missing_indices_file):
#        print('llllllllllllllllllll')
#        erasing_pool = torch.arange(n)[~data.train_mask] # keep training set always full feature
        erasing_pool = torch.arange(n)
        size = int(len(erasing_pool) * (missing_rate/100))
        idx_erased = np.random.choice(erasing_pool, size=size, replace=False)
        np.save(missing_indices_file, idx_erased)
        pass
    else:
        idx_erased = np.load(missing_indices_file)
    # erasing feature for random missing 
    if missing_rate > 0:
        data.x[idx_erased] = 0
    
    if cuda:
        data.x = data.x.cuda()
        data.y = data.y.cuda()
        data.adj = data.adj.cuda()
    
    return data


def load_data(data_name='cora', normalize_feature=True, missing_rate=0, cuda=False):
    # can use other dataset, some doesn't have mask
    data = geo_data.Planetoid(os.path.join(DATA_ROOT, data_name), data_name).data
    # data = geo_data.Coauthor(os.path.join(DATA_ROOT, data_name), data_name).data
#    data1 = get_adjacency(data, data_name, normalize_feature, missing_rate, cuda)
#    print('整个图的边数：',len(data1.adj._values()))
#     print(data)
#     print(data.__dict__)
#     print(type(data.edge_index))
#     print(type(data.x))
#     print(type(data.y))
#     print(type(data.edge_index))
#     for i in range(len(data.__dict__)):
#         print(type(data.__dict__))
    # original split
#     data.train_mask = data.train_mask.type(torch.bool)
#     data.val_mask = data.val_mask.type(torch.bool)
#     # data.test_mask = data.test_mask.type(torch.bool)    
#     # expand test_mask to all rest nodes 
#     data.test_mask = ~(data.train_mask + data.val_mask)
    
# if shuffle, run the following block
    # n = len(data.y)
    # m = data.edge_index.size(1)
    # data_idx = list(range(n))
    # random.seed(1421)
    # random.shuffle(data_idx)
    # #print('data_idx:',data_idx)
    # print('data_idx:',len(data_idx))
    # data.x = data.x[data_idx]
    # data.y = data.y[data_idx]
    # for i in range(m):
    #     j = data.edge_index[0,i]
    #     data.edge_index[0,i] = data_idx[j]
    #     k = data.edge_index[1,i]
    #     data.edge_index[1,i] = data_idx[k]
    '''
    data split ratio
    cora:2,4,4
    citeseer:1,4,5,我们3，3，4
    pubmed:0.5,4.5,5
    '''
    p_train_data, p_val_data, p_test_data = partition(data, [0.3,0.97,8.73])
    
    # get adjacency matrix
    train_data = get_adjacency(p_train_data, data_name, normalize_feature, missing_rate, cuda)
    val_data = get_adjacency(p_val_data, data_name, normalize_feature, missing_rate, cuda)
    test_data = get_adjacency(p_test_data, data_name, normalize_feature, missing_rate, cuda)
    print('训练集边数：',len(train_data.adj._values()))
    
    return train_data, val_data, test_data
    
# 如果正常训练，下面部分需要注释
    '''
    # 拆分训练集
    ratio = [3,3,4]
    nn = len(data.y)
    mm = train_data.edge_index.size(1)
    train_num = int(nn * ratio[0] / 10)
    data_idx_train = list(range(train_num))  # 给训练集节点重新编号
    
    # 要修改的种子数1000，500，300，1200，1500
    random.seed(1500)
    random.shuffle(data_idx_train)
    # 原始训练集的节点idx字典
    # 每次更换种子数，这个字典随之变化
    dic = {}
    for i in range(train_num):
        dic[i] = data_idx_train[i]
    
    train_data.x = train_data.x[data_idx_train]
    train_data.y = train_data.y[data_idx_train]
    for i in range(mm):
        j = train_data.edge_index[0,i]
        train_data.edge_index[0,i] = data_idx_train[j]
        k = train_data.edge_index[1,i]
        train_data.edge_index[1,i] = data_idx_train[k]
    pp_train_data, pp_test_data, train_num, test_num = partition_two(p_train_data, data_idx_train, [5,5])
    train_data = get_adjacency(pp_train_data, data_name, normalize_feature, missing_rate, cuda)
    test_data = get_adjacency(pp_test_data, data_name, normalize_feature, missing_rate, cuda)
    print('train_num:  ', train_num)
    print('训练集的训练集边数：', len(train_data.adj._values()))
#    train_idx_lst = list(range(train_num))
#    test_idx_lst = list(range(train_num, train_num+test_num))
#    print('111111111')
#    print(train_num)
#    print(test_num)
#    print(len(train_idx_lst))
#    print(len(test_idx_lst))

    return train_data, test_data, dic, train_num
#     return data
    '''
    
# def load_data_origin(data_name='cora', normalize_feature=True, missing_rate=0, cuda=False):
#     # TODO use new dataset
#     # TODO generate new neg
#     # can use other dataset, some doesn't have mask
#     data = geo_data.Planetoid(os.path.join(DATA_ROOT, data_name), data_name).data
#     # original split
#     data.train_mask = data.train_mask.type(torch.bool)
#     data.val_mask = data.val_mask.type(torch.bool)
#     # data.test_mask = data.test_mask.type(torch.bool)    
#     # expand test_mask to all rest nodes 
#     data.test_mask = ~(data.train_mask + data.val_mask)
#     # get adjacency matrix
#     n = len(data.x)
#     adj = sp.csr_matrix((np.ones(data.edge_index.shape[1]), data.edge_index), shape=(n,n))
#     adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj) + sp.eye(adj.shape[0])
#     adj = normalize_adj_row(adj) # symmetric normalization works bad, but why? Test more.
#     data.adj = to_torch_sparse(adj)
#     # normalize feature
#     if normalize_feature:
#         data.x = row_l1_normalize(data.x)
    
#     # generate missing feature setting 
#     indices_dir = os.path.join(DATA_ROOT, data_name, 'indices')
#     if not os.path.isdir(indices_dir): 
#         os.mkdir(indices_dir)
#     missing_indices_file = os.path.join(indices_dir, "indices_missing_rate={}.npy".format(missing_rate))
#     if not os.path.exists(missing_indices_file):
#         erasing_pool = torch.arange(n)[~data.train_mask] # keep training set always full feature
#         size = int(len(erasing_pool) * (missing_rate/100))
#         idx_erased = np.random.choice(erasing_pool, size=size, replace=False)
#         np.save(missing_indices_file, idx_erased)
#     else:
#         idx_erased = np.load(missing_indices_file)
#     # erasing feature for random missing 
#     if missing_rate > 0:
#         data.x[idx_erased] = 0
    
#     if cuda:
#         data.x = data.x.cuda()
#         data.y = data.y.cuda()
#         data.adj = data.adj.cuda()

#     print('[INFO] data.x.shape', data.x.shape)
#     print('[INFO] data.y.shape', data.y.shape)
#     print('[INFO] data.adj.shape', data.adj.shape)
    
#     return data  

def normalize_adj(adj):
    """Symmetrically normalize adjacency matrix."""
    # add self-loop and normalization also affects performance a lot 
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()

def normalize_adj_row(adj):
    """Row-normalize sparse matrix"""
    rowsum = np.array(adj.sum(1))
    r_inv = np.power(rowsum, -1).flatten()
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    mx = r_mat_inv.dot(adj)
    return mx 

def to_torch_sparse(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)

def row_l1_normalize(X):
    norm = 1e-6 + X.sum(dim=1, keepdim=True)
    return X/norm

if __name__ == "__main__":
    import sys
    print(sys.version)
    # test goes here
#     data = load_data(cuda=True)
    train_data, val_data, test_data = load_data(cuda=True)
#     data, adj_origin = load_data(cuda=True)
#     print(data.train_mask[:150])
#     print(adj_origin)
#     print(get_graph_distance(2,332,adj_origin.indices,adj_origin.indptr))