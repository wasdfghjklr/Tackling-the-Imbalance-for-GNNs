import torch
import math
import numpy as np
import time
from sklearn import metrics
import torch.nn.functional as F
from sklearn.metrics import f1_score, accuracy_score
from sklearn.metrics import confusion_matrix
from numpy import *

def f(max_epoch, epoch, eps):
    f_value = 1/2*math.cos(epoch*math.pi/max_epoch) + 1/2 + eps
    return f_value

def euclidian_distance(x, y):
    return torch.sqrt(torch.sum((x - y) ** 2))

'''
去掉0
'''
#def get_triplets(hard_pairs, embedding, topn, margin=0.2):
#    anchor_idx_list = list(hard_pairs[0].cpu().numpy())
#    positive_idx_list = list(hard_pairs[1].cpu().numpy())
#    negative_idx_list = list(hard_pairs[2].cpu().numpy())
#    euclidian_distance_list = []
#    anchor_idx_list_no0 = []
#    positive_idx_list_no0 = []
#    negative_idx_list_no0 = []
#
#    len_triplets = len(anchor_idx_list)
#    for i in range(len_triplets):
#        anchor = embedding[anchor_idx_list[i]]
#        pos = embedding[positive_idx_list[i]]
#        neg = embedding[negative_idx_list[i]]
#        distance = max(0,euclidian_distance(anchor, pos) - euclidian_distance(anchor, neg) + margin)
#        if distance > 0:
#            #print('disttttt:',distance)
#            anchor_idx_list_no0.append(anchor_idx_list[i])
#            positive_idx_list_no0.append(positive_idx_list[i])
#            negative_idx_list_no0.append(negative_idx_list[i])
#            euclidian_distance_list.append(distance)
#
#    sorted_index = np.argsort(euclidian_distance_list)[::-1]
#    euclidian_distance_list = [euclidian_distance_list[i] for i in sorted_index][:int(topn * len_triplets)]
#    anchor_idx_list_no0 = [anchor_idx_list_no0[i] for i in sorted_index][:int(topn * len_triplets)]
#    positive_idx_list_no0 = [positive_idx_list_no0[i] for i in sorted_index][:int(topn * len_triplets)]
#    negative_idx_list_no0 = [negative_idx_list_no0[i] for i in sorted_index][:int(topn * len_triplets)]
#    return (torch.tensor(anchor_idx_list_no0).to('cuda'), torch.tensor(positive_idx_list_no0).to('cuda'), torch.tensor(negative_idx_list_no0).to('cuda'))

# def get_triplets(hard_pairs, embedding, topn, margin=0.2):
#     anchor_idx_list = list(hard_pairs[0].cpu().numpy())
#     positive_idx_list = list(hard_pairs[1].cpu().numpy())
#     negative_idx_list = list(hard_pairs[2].cpu().numpy())
#     euclidian_distance_list = []

#     len_triplets = len(anchor_idx_list)
#     for i in range(len_triplets):
#         anchor = embedding[anchor_idx_list[i]]
#         pos = embedding[positive_idx_list[i]]
#         neg = embedding[negative_idx_list[i]]
#         distance = max(0,euclidian_distance(anchor, pos) - euclidian_distance(anchor, neg) + margin)
#         euclidian_distance_list.append(distance)

#     sorted_index = np.argsort(euclidian_distance_list)[::-1]
#     euclidian_distance_list = [euclidian_distance_list[i] for i in sorted_index][:int(topn * len_triplets)]
#     anchor_idx_list = [anchor_idx_list[i] for i in sorted_index][:int(topn * len_triplets)]
#     positive_idx_list = [positive_idx_list[i] for i in sorted_index][:int(topn * len_triplets)]
#     negative_idx_list = [negative_idx_list[i] for i in sorted_index][:int(topn * len_triplets)]
#     return (torch.tensor(anchor_idx_list).to('cuda'), torch.tensor(positive_idx_list).to('cuda'), torch.tensor(negative_idx_list).to('cuda'))
'''
gcn-ml和gcn使用37行
'''
#def train(net, optimizer, criterion1,criterion2, data, miner, epoch, max_epoch, topn, margin):    
def train(net, optimizer, criterion1, data, epoch, max_epoch, hard_pairs):
    net.train()
    optimizer.zero_grad()
    output, output_hidden = net(data.x, data.adj)
    #default_hard_pairs = miner(output, data.y)
#    print('default_hard_pairs:', default_hard_pairs)
#     t1 = time.time()
    #hard_pairs = get_triplets(hard_pairs, output, topn, margin)
#     if epoch%50 == 0:
#         print('hard_miner_size:',len(hard_pairs[0]))

#     t2 = time.time()
#    print('time:',t2-t1)
    '''GCN-ML'''
    #loss1 = criterion1(output, data.y, default_hard_pairs) #the original loss of miners
    '''GCN-OURS'''
    loss1 = criterion1(output_hidden, data.y, hard_pairs)
    
    loss2 = focal_loss(output, data.y)
# #     #print('classification loss:',loss2)
    p = 0.3  #to be tested 论文里的
    eps = 0.001 #to be tested
    f_value = f(max_epoch,epoch,eps)
    if epoch < int(p*max_epoch):
        loss = loss2 + f_value*loss1
    else:
        loss = loss2 + eps*loss1
    print('loss1:    ',loss1)
    print('loss2:    ',loss2)
    '''barely GCN'''
#    loss = loss2
    
#     acc = accuracy(output[data.train_mask], data.y[data.train_mask])
    acc = accuracy(output, data.y)
    loss.backward()
    optimizer.step()

    macro_f1_train = macrof1(output, data.y)
    gmean_train = g_mean(output, data.y)
    return loss, acc, macro_f1_train, gmean_train

def val(net, criterion2, data):
    net.eval()
#    output = net(data.x, data.adj)
    output, output_hidden = net(data.x, data.adj)
    loss_val = criterion2(output, data.y)
    acc_val = accuracy(output, data.y)
    macro_f1_val = macrof1(output, data.y)
    gmean_val = g_mean(output, data.y)
    return loss_val, acc_val, macro_f1_val, gmean_val

def test(net, criterion2, data):
    net.eval()
    output, output_hidden = net(data.x, data.adj)
    loss_test = criterion2(output, data.y)
    acc_test = accuracy(output, data.y)
    macro_f1_test = macrof1(output, data.y)
    gmean_test = g_mean(output, data.y)
    return loss_test, acc_test, macro_f1_test, gmean_test

#def test(net, criterion2, data, nlayer,data_name, model_name):
#    labels = data.y
#    net.eval()
##    output = net(data.x, data.adj)
#    output, output_hidden = net(data.x, data.adj)
#    preds = output.max(1)[1].type_as(labels)
#    print('len:',len(preds))
#    print('len_data:',len(output))
#    correct = preds.eq(labels).double()
#    correct_list = correct.cpu().numpy().tolist() 
#    correct_place = [i for i in range(len(correct)) if correct[i]==1]    
#    false_place = list(set(range(len(labels)))-set(correct_place))
#    correct_place = np.array(correct_place)
#    false_place = np.array(false_place)
#    print('correct_place:',correct_place)
#    print('false_place:',false_place)
#    if os.path.exists('./classification_result/%s'% model_name + '/' + data_name):
#        pass
#    else:
#        os.mkdir('./classification_result/%s'% model_name + '/' + data_name)
#    path = './classification_result/%s'% model_name + '/' + data_name
#    np.save(path + '/correct_place_%d.npy'%nlayer,correct_place)
#    np.save(path + '/false_place_%d.npy'%nlayer,false_place)
#    
#    loss_test = criterion2(output, data.y)
#    acc_test = accuracy(output, data.y)
#    return loss_test, acc_test

def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    # correct = preds.eq(labels).double()
    # correct = correct.sum()
    acc = accuracy_score(labels, preds)
    # return correct / len(labels)
    return acc

def focal_loss(outputs, y_true):
    probability = F.softmax(outputs, dim=1)  # shape [num_samples,num_classes]
    log_P = torch.log(probability)
    one_hot = torch.zeros(probability.shape, dtype=float).scatter_(1, torch.unsqueeze(y_true, dim=1), 1)
    loss3 = 0
    dic_sum_prob = {}
    dic_label_coun = {}
    weight_fl = {}
    for i in range(probability.shape[1]):
        # 为每个label的个数和总的p赋初值
        dic_sum_prob[i] = 0
        dic_label_coun[i] = 0
        weight_fl[i] = 0           
    for j in range(probability.shape[0]):
        dic_sum_prob[y_true[j].detach().cpu().numpy().tolist()] += probability[j][y_true[j]].detach().cpu().numpy().tolist()
        dic_label_coun[y_true[j].detach().cpu().numpy().tolist()] += 1
    for k in weight_fl:
        if dic_label_coun[k] == 0:
            weight_fl[k] = 0
        else:
            weight_fl[k] = dic_sum_prob[k]/dic_label_coun[k]
    for i in range(probability.shape[0]):
        loss3 -= one_hot[i] * log_P[i] * math.pow((1-weight_fl[y_true[i].detach().cpu().numpy().tolist()]),2)
    loss3 = loss3.sum()
    return loss3

def macrof1(output, labels):
    preds = output.max(1)[1].type_as(labels)
    return f1_score(labels, preds, average='macro')


def g_mean(output, labels):
    preds = output.max(1)[1].type_as(labels)
    # precision = metrics.precision_score(labels, preds, average = 'macro')
    n = int(max(labels)+1)
    specificity = spe(labels,preds,n)
    print(specificity)
    recall = metrics.recall_score(labels, preds, average = 'macro')
    return math.sqrt(specificity * recall)

def dic_acc_lable(net, data):
    net.eval()
    output, _ = net(data.x, data.adj)
    # print(len(output))
    labels = data.y.cpu().numpy().tolist()
    # print(len(labels))
    # print(type(output))
    # print(output)
    # print(len(output))
    # print(output[0])
    # print(len(output[0]))
    preds = output.max(1)[1].type_as(data.y)
    dic_acc = {}
    dic_lable = {}
    for i, e in enumerate(labels):
        if e in dic_lable:  # 如果当前lable以前出现过
            dic_lable[e] += 1
            if e == preds[i]:  # 如果当前lable和预测的一致
                if e in dic_acc:
                    dic_acc[e] += 1  # acc的dict里对应的value
                else:
                    dic_acc[e] = 1
        else:  # 如果当前lable之前没出现过，说明两个dict里都不会有
            dic_lable[e] = 1
            if e == preds[i]:  # 如果当前lable和预测的一致
                if e in dic_acc:
                    dic_acc[e] += 1  # acc的dict里对应的value
                else:
                    dic_acc[e] = 1
    return dic_acc, dic_lable, labels, preds

def spe(Y_test,Y_pred,n):
    
    spe = []
    con_mat = confusion_matrix(Y_test,Y_pred)
    for i in range(n):
        number = np.sum(con_mat[:,:])
        tp = con_mat[i][i]
        fn = np.sum(con_mat[i,:]) - tp
        fp = np.sum(con_mat[:,i]) - tp    
        tn = number - tp - fn - fp
        spe1 = tn / (tn + fp)
        spe.append(spe1)
    speci = mean(spe)
    return speci