from layers import *
import torch.nn.functional as F
import torch
import scipy.sparse as sp
import torch.nn as nn


class SGC(nn.Module):
    # for SGC we use data without normalization
    def __init__(self, nfeat, nhid, nclass, dropout,
                 nlayer=2, norm_mode='None', norm_scale=10, **kwargs):
        super(SGC, self).__init__()
        self.linear = torch.nn.Linear(nfeat, nclass)
        self.linear_1 = torch.nn.Linear(nfeat, nfeat)
        self.linear_ = torch.nn.Linear(nfeat, nclass)
        self.dropout = nn.Dropout(p=dropout)
        self.nlayer = nlayer
        self.relu = nn.ReLU(True)

    def forward(self, x, adj):

        x_uni = x
        for _ in range(self.nlayer):
            x_uni = adj.mm(x_uni)
        x_uni = self.dropout(x_uni)
        x_uni = self.linear(x_uni)


#        I = torch.eye(adj.shape[0], adj.shape[0]).to('cuda')
        x_noi = x

        x_noi = self.relu(x_noi)
        x_noi = self.dropout(x_noi)
        x_noi = self.linear_1(x_noi)
        x_noi = self.relu(x_noi)
        x_noi = self.dropout(x_noi)
        x_noi = self.linear_(x_noi)

        return x_uni, x_noi


class DGN_SGC(nn.Module):
    # for SGC we use data without normalization
    def __init__(self, nfeat, nhid, nclass, dropout, num_class=3, balancing_f=5*1e-4, nlayer=2, norm_mode='None', **kwargs):
        super(DGN_SGC, self).__init__()
        self.linear = torch.nn.Linear(nfeat, nclass)
        self.norm = DGN(nfeat, num_class, balancing_f)
        self.dropout = nn.Dropout(p=dropout)
        self.nlayer = nlayer

    def forward(self, x, adj):
        x = self.norm(x)
        for _ in range(self.nlayer):
            x = adj.mm(x)
            x = self.norm(x)
        x = self.dropout(x)
        x = self.linear(x)
        return x


class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout,
                 norm_mode='None', norm_scale=1, **kwargs):
        super(GCN, self).__init__()
        self.gc1 = GraphConv(nfeat, nhid)
        self.gc1_ = GraphConv(nfeat, nhid)
        self.gc2 = GraphConv(nhid, nclass)
#        self.gc2 = GraphConv(nhid, nhid)
        self.gc2_ = GraphConv(nhid, nhid)
        self.gc2_linear = nn.Linear(nhid, nclass)
        self.sigmoid = torch.nn.Sigmoid()
#        self.gc3 = GraphConv(nhid, nhid)
        self.dropout = nn.Dropout(p=dropout)
        self.relu = nn.ReLU(True)
        self.gc3_linear = nn.Linear(nhid, nclass)

    def to_torch_sparse(self, sparse_mx):
        """Convert a scipy sparse matrix to a torch sparse tensor."""
        sparse_mx = sparse_mx.tocoo().astype(np.float32)
        indices = torch.from_numpy(
            np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
        values = torch.from_numpy(sparse_mx.data)
        shape = torch.Size(sparse_mx.shape)
        return torch.sparse.FloatTensor(indices, values, shape)

    def forward(self, x, adj):
        x = self.dropout(x)

        x_uni = self.gc1(x, adj)
        x_uni = self.relu(x_uni)
        x_uni = self.dropout(x_uni)
        x_uni = self.gc2(x_uni, adj)
        x_uni_logit = x_uni


#        I = torch.eye(adj.shape[0], adj.shape[0]).to('cuda')

        n = adj.shape[0]
        edge_index = [[i for i in range(n)], [j for j in range(n)]]
        edge_index = torch.IntTensor(edge_index)
        II = sp.csr_matrix(
            (np.ones(edge_index.shape[1]), edge_index), shape=(n, n))
        I = self.to_torch_sparse(II)

        x_noi = self.gc1_(x, I)
        x_noi = self.relu(x_noi)
        x_noi = self.dropout(x_noi)
#        x_noi = self.gc2_(x_noi, I)
#        x_noi = self.relu(x_noi)
#        x_noi = self.dropout(x_noi)
#        x1_noi = torch.nn.functional.normalize(x_noi)
        x_noi_logit = self.gc3_linear(x_noi)

        return x_uni_logit, x_noi_logit


class GAT(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout, nhead,
                 norm_mode='None', norm_scale=1, **kwargs):
        super(GAT, self).__init__()
        alpha_droprate = dropout
        self.gac1 = GraphAttConv(nfeat, nhid, nhead, alpha_droprate)
        self.gac2 = GraphAttConv(nhid, nclass, 1, alpha_droprate)  # 原始
        self.gac2_ = GraphAttConv(nhid, nhid, 1, alpha_droprate)
        self.gac2_linear = nn.Linear(nhid, nclass)
        self.gac3_linear = nn.Linear(nhid, nclass)
        self.gac1_linear = nn.Linear(nfeat, nhid)
        self.gac1_linear_ = nn.Linear(nhid, nhid)
        self.dropout = nn.Dropout(p=dropout)
        self.relu = nn.ELU(True)

    def to_torch_sparse(self, sparse_mx):
        """Convert a scipy sparse matrix to a torch sparse tensor."""
        sparse_mx = sparse_mx.tocoo().astype(np.float32)
        indices = torch.from_numpy(
            np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
        values = torch.from_numpy(sparse_mx.data)
        shape = torch.Size(sparse_mx.shape)
        return torch.sparse.FloatTensor(indices, values, shape)

    def forward(self, x, adj):
        x = self.dropout(x)

        x_uni = self.gac1(x, adj)
        x_uni = self.relu(x_uni)
        x_uni = self.dropout(x_uni)
        x_uni = self.gac2(x_uni, adj)
        x_uni_logit = x_uni


#        I = sp.eye(adj.shape[0])
#        I = self.to_torch_sparse(I).cuda()
#        x = self.dropout(x)
        x_noi = self.gac1_linear(x)
        x_noi = self.relu(x_noi)
        x_noi = self.dropout(x_noi)
        x_noi = self.gac1_linear_(x_noi)
        x_noi = self.relu(x_noi)
        x_noi = self.dropout(x_noi)
        x_noi_logit = self.gac3_linear(x_noi)

        return x_uni_logit, x_noi_logit


class DeepGCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout, nlayer=2, residual=0,
                 norm_mode='None', norm_scale=1, **kwargs):
        super(DeepGCN, self).__init__()
        assert nlayer >= 1
        self.hidden_layers = nn.ModuleList([
            GraphConv(nfeat if i == 0 else nhid, nhid)
            for i in range(nlayer-1)
        ])
        self.out_layer = GraphConv(nfeat if nlayer == 1 else nhid, nclass)

        self.dropout = nn.Dropout(p=dropout)
        self.dropout_rate = dropout
        self.relu = nn.ReLU(True)
#        self.norm = PairNorm(norm_mode, norm_scale)
        self.skip = residual

    def forward(self, x, adj):
        x_old = 0
        for i, layer in enumerate(self.hidden_layers):
            x = self.dropout(x)
            x = layer(x, adj)
#            x = self.norm(x)
            x = self.relu(x)
            if self.skip > 0 and i % self.skip == 0:
                x = x + x_old
                x_old = x

        x = self.dropout(x)
        x = self.out_layer(x, adj)
        # print('out_put:',x)
        # print('out_putshape:',len(x))  return:2708
        return x


class DeepGAT(nn.Module):
    def __init__(self, nfeat, nhid, nclass, dropout, nlayer=2, residual=0, nhead=1,
                 norm_mode='None', norm_scale=1, **kwargs):
        super(DeepGAT, self).__init__()
        assert nlayer >= 1
        alpha_droprate = dropout
        self.hidden_layers = nn.ModuleList([
            GraphAttConv(nfeat if i == 0 else nhid,
                         nhid, nhead, alpha_droprate)
            for i in range(nlayer-1)
        ])
        self.out_layer = GraphAttConv(
            nfeat if nlayer == 1 else nhid, nclass, 1, alpha_droprate)

        self.dropout = nn.Dropout(p=dropout)
        self.relu = nn.ELU(True)
        self.norm = PairNorm(norm_mode, norm_scale)
        self.skip = residual

    def forward(self, x, adj):
        x_old = 0
        for i, layer in enumerate(self.hidden_layers):
            x = self.dropout(x)
            x = layer(x, adj)
            x = self.norm(x)
            x = self.relu(x)
            if self.skip > 0 and i % self.skip == 0:
                x = x + x_old
                x_old = x

        x = self.dropout(x)
        x = self.out_layer(x, adj)
        return x
