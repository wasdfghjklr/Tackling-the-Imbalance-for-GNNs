import torch
import math
import numpy as np
import time
import torch.nn.functional as F
from sklearn import metrics
from sklearn.metrics import f1_score, accuracy_score
from sklearn.metrics import confusion_matrix
from numpy import *

def f(max_epoch, epoch, eps):
    f_value = 1/2*math.cos(epoch*math.pi/max_epoch) + 1/2 + eps
    return f_value


def euclidian_distance(x, y):
    return torch.sqrt(torch.sum((x - y) ** 2))


def train(net, optimizer, criterion2, data, epoch, max_epoch, topn, margin):
    net.train()
    optimizer.zero_grad()
    output = net(data.x, data.adj)

    loss2 = focal_loss(output[data.train_mask], data.y[data.train_mask])
    loss = loss2

    acc = accuracy(output[data.train_mask], data.y[data.train_mask])
    loss.backward()
    optimizer.step()

    macrof1_train = macrof1(output[data.train_mask], data.y[data.train_mask])
    gmean_train = g_mean(output[data.train_mask], data.y[data.train_mask])

    return loss, acc, macrof1_train, gmean_train


def val(net, criterion2, data):
    net.eval()
    output = net(data.x, data.adj)
    loss_val = criterion2(output[data.val_mask], data.y[data.val_mask])
    acc_val = accuracy(output[data.val_mask], data.y[data.val_mask])
    macrof1_val = macrof1(output[data.val_mask], data.y[data.val_mask])
    gmean_val = g_mean(output[data.val_mask], data.y[data.val_mask])
    return loss_val, acc_val, macrof1_val, gmean_val


def test(net, criterion2, data):
    net.eval()
    output = net(data.x, data.adj)
    loss_test = criterion2(output[data.test_mask], data.y[data.test_mask])
    acc_test = accuracy(output[data.test_mask], data.y[data.test_mask])
    macrof1_test = macrof1(output[data.test_mask], data.y[data.test_mask])
    gmean_test = g_mean(output[data.test_mask], data.y[data.test_mask])
    return loss_test, acc_test, macrof1_test, gmean_test


def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    # correct = preds.eq(labels).double()
    # correct = correct.sum()
    acc = accuracy_score(labels, preds)
    # return correct / len(labels)
    return acc

def focal_loss(outputs, y_true):
    probability = F.softmax(outputs, dim=1)  # shape [num_samples,num_classes]
    log_P = torch.log(probability)
    one_hot = torch.zeros(probability.shape, dtype=float).scatter_(1, torch.unsqueeze(y_true, dim=1), 1)
    loss3 = 0
    dic_sum_prob = {}
    dic_label_coun = {}
    weight_fl = {}
    for i in range(probability.shape[1]):
        # 为每个label的个数和总的p赋初值
        dic_sum_prob[i] = 0
        dic_label_coun[i] = 0
        weight_fl[i] = 0           
    for j in range(probability.shape[0]):
        dic_sum_prob[y_true[j].detach().cpu().numpy().tolist()] += probability[j][y_true[j]].detach().cpu().numpy().tolist()
        dic_label_coun[y_true[j].detach().cpu().numpy().tolist()] += 1
    for k in weight_fl:
        if dic_label_coun[k] == 0:
            weight_fl[k] = 0
        else:
            weight_fl[k] = dic_sum_prob[k]/dic_label_coun[k]
    for i in range(probability.shape[0]):
        loss3 -= one_hot[i] * log_P[i] * math.pow((1-weight_fl[y_true[i].detach().cpu().numpy().tolist()]),2)
    loss3 = loss3.sum()
    return loss3

def macrof1(output, labels):
    preds = output.max(1)[1].type_as(labels)
    return f1_score(labels, preds, average='macro')


def g_mean(output, labels):
    preds = output.max(1)[1].type_as(labels)
    # precision = metrics.precision_score(labels, preds, average = 'macro')
    n = int(max(labels)+1)
    specificity = spe(labels,preds,n)
    print(specificity)
    recall = metrics.recall_score(labels, preds, average = 'macro')
    return math.sqrt(specificity * recall)

def dic_acc_lable(net, data):
    net.eval()
    output = net(data.x, data.adj)
    # print(len(output))
    # labels = data.y.cpu().numpy().tolist()

    labels = data.y[data.test_mask].numpy().tolist()
    preds = output[data.test_mask].max(1)[1].type_as(data.y)

    dic_acc = {}
    dic_lable = {}
    for i, e in enumerate(labels):
        if e in dic_lable:  # 如果当前lable以前出现过
            dic_lable[e] += 1
            if e == preds[i]:  # 如果当前lable和预测的一致
                if e in dic_acc:
                    dic_acc[e] += 1  # acc的dict里对应的value
                else:
                    dic_acc[e] = 1
        else:  # 如果当前lable之前没出现过，说明两个dict里都不会有
            dic_lable[e] = 1
            if e == preds[i]:  # 如果当前lable和预测的一致
                if e in dic_acc:
                    dic_acc[e] += 1  # acc的dict里对应的value
                else:
                    dic_acc[e] = 1
    return dic_acc, dic_lable, labels, preds

def spe(Y_test,Y_pred,n):
    
    spe = []
    con_mat = confusion_matrix(Y_test,Y_pred)
    for i in range(n):
        number = np.sum(con_mat[:,:])
        tp = con_mat[i][i]
        fn = np.sum(con_mat[i,:]) - tp
        fp = np.sum(con_mat[:,i]) - tp    
        tn = number - tp - fn - fp
        spe1 = tn / (tn + fp)
        spe.append(spe1)
    speci = mean(spe)
    return speci