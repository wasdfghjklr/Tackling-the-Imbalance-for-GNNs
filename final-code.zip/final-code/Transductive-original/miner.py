import torch
import numpy as np
import torch.nn.functional as F
from torch.utils.data.sampler import WeightedRandomSampler
from torch.utils.data import DataLoader


def euclidian_distance(x, y):
    return torch.sqrt(torch.sum((x - y) ** 2))


def anchor_select_exp(data, sample_ratio):
    adj = data.adj
    label = data.y
    train_index_list = [i for i, v in enumerate(data.train_mask) if v]
    anchor_label_list = []
    anchor_index_list = []
    for anchor_index in train_index_list:
        anchor_index_list.append(anchor_index)
        anchor_label_list.append(int(label[anchor_index].cpu().numpy()))
    dataset = list(zip(anchor_index_list, anchor_label_list))
    anchor_hardpoint_list = []
    for anchor_node in anchor_index_list:
        subanchor_label_list = []
        # get every anchor-node's 1-neighbor
        indices_1 = adj[anchor_node]._indices()
        anchor_label = label[anchor_node]
        indices_2_list = []
        for index_2 in indices_1.cpu().numpy()[0]:
            indices_2 = adj[index_2]._indices()
            # get every anchor-node's 2-neighbor
            indices_2_list += list(indices_2.cpu().numpy()[0])

        indices_list_all = list(indices_1.cpu().numpy()[0]) + indices_2_list
        indices_list_all = list(set(indices_list_all))
        for node in indices_list_all:
            subanchor_label_list.append(int(label[node].cpu().numpy()))
        data_summery = [subanchor_label_list.count(
            i) for i in range(int(data.y.max()) + 1)]
        data_summery = torch.Tensor(data_summery)
        # print('data_summery:',data_summery)
        data_summery_ideal = torch.Tensor(
            len(indices_list_all) * np.eye(1, int(data.y.max()) + 1, label[anchor_node])[0])
        # print('data_summery_ideal:',data_summery_ideal)
        numerator = euclidian_distance(data_summery, data_summery_ideal)
        # print('numerator:',numerator)
        denominator = 2 * euclidian_distance(data_summery_ideal, 0)
        hard_point = numerator / denominator
        anchor_hardpoint_list.append(hard_point)
    data_class_count = [anchor_label_list.count(
        i) for i in range(int(data.y.max()) + 1)]
    data_class_score = np.zeros((1, int(data.y.max()) + 1))
#    print('data_class_count:',data_class_count)
    for j in range(int(data.y.max()) + 1):
        for i, hardpoint in enumerate(anchor_hardpoint_list):
            if label[i] == j:
                data_class_score[0][j] = data_class_score[0][j] + hardpoint
        data_class_score[0][j] = data_class_score[0][j]/data_class_count[j]
#    print('data_class_score:',data_class_score)

#    print('anchor_hardpoint_list:',anchor_hardpoint_list)

    sampler = WeightedRandomSampler(anchor_hardpoint_list,
                                    num_samples=int(
                                        len(anchor_index_list) * sample_ratio),
                                    replacement=False)
    dataloader = DataLoader(dataset,
                            batch_size=int(
                                len(anchor_index_list) * sample_ratio),
                            sampler=sampler)
    for anchor_index_list, labels in dataloader:
        anchor_selected = anchor_index_list
    # print('anchor_selected:',len(anchor_selected))
    return anchor_selected


def anchor_select_softmax(data, sample_ratio):
    adj = data.adj
    label = data.y
#     train_index_list = list(range(len(data.y)))
    train_index_list = [i for i, v in enumerate(data.train_mask) if v]
    anchor_label_list = []
    anchor_index_list = []
    for anchor_index in train_index_list:
        anchor_index_list.append(anchor_index)
        anchor_label_list.append(int(label[anchor_index].cpu().numpy()))
    dataset = list(zip(anchor_index_list, anchor_label_list))
    data_summery = [anchor_label_list.count(
        i) for i in range(int(data.y.max()) + 1)]
    data_summery.reverse()
    data_summery = torch.Tensor(data_summery)
    data_prob_dist = F.softmax(data_summery).numpy()
    weights = []
    for i, label in enumerate(anchor_label_list):
        weights.append(data_prob_dist[label])
    sampler = WeightedRandomSampler(weights,
                                    num_samples=int(
                                        len(anchor_index_list) * sample_ratio),
                                    replacement=False)
    dataloader = DataLoader(dataset,
                            batch_size=int(
                                len(anchor_index_list) * sample_ratio),
                            sampler=sampler)
    for anchor_index_list, labels in dataloader:
        anchor_selected = anchor_index_list
    return anchor_selected


'''
mining via topology structure of graph
'''


def triple_mining(data, topk_neg, topk_pos, anchor_sample_ratio, miner):
    adj = data.adj
    label = data.y
    feature = data.x
    train_index_list_ori = [i for i, v in enumerate(data.train_mask) if v]
    if miner == 1:
        train_index_list = anchor_select_exp(
            data, anchor_sample_ratio)  # anchor sampling via hard point
    if miner == 2:
        train_index_list = anchor_select_softmax(
            data, anchor_sample_ratio)  # anchor sampling via softmax
    anchor_idx_list = []
    positive_idx_list = []
    negative_idx_list = []

    for anchor_index in train_index_list:
        local_negative_list = []
        local_positive_list = []

        indices_1 = adj[anchor_index]._indices()
        values_1 = adj[anchor_index]._values()
        anchor_label = label[anchor_index]

        # get hard negative
        for index in indices_1.cpu().numpy()[0]:
            neg_euclidian_distance_list = []
            # FIXME should compare the value
            if not torch.all(torch.eq(label[index], anchor_label)):
                local_negative_list.append(index)
                anchor = feature[anchor_index]
                neg = feature[index]
                distance = euclidian_distance(anchor, neg)
                neg_euclidian_distance_list.append(distance)
        sorted_index_neg = np.argsort(neg_euclidian_distance_list)[::-1]
        local_negative_list = [local_negative_list[i]
                               for i in sorted_index_neg]
#        print('local_negative_list:',local_negative_list)

        indices_2_list = []
        for index_2 in indices_1.cpu().numpy()[0]:
            indices_2 = adj[index_2]._indices()
            values_2 = adj[index_2]._values()
            indices_2_list += list(indices_2.cpu().numpy()[0])

        indices_3_list = []
        for index_3 in indices_2.cpu().numpy()[0]:
            indices_3 = adj[index_3]._indices()
            values_3 = adj[index_3]._values()
            indices_3_list += list(indices_3.cpu().numpy()[0])

        indices_list = list(indices_1.cpu().numpy()[
                            0]) + indices_2_list + indices_3_list
        indices_list = list(set(indices_list))

        # get hard positive
        pos_euclidian_distance_list = []
        for i, l in enumerate(label):
            # for i in range(len(label)):
            if i not in indices_list and torch.eq(l, anchor_label):
                local_positive_list.append(i)
                anchor = feature[anchor_index]
                pos = feature[i]
                distance = euclidian_distance(anchor, pos)
                pos_euclidian_distance_list.append(distance)
        sorted_index_pos = np.argsort(pos_euclidian_distance_list)[::-1]
        #pos_idx_list = [local_positive_list[i] for i in sorted_index_pos][:int(topk_pos * len(local_positive_list))]
        local_positive_list = [local_positive_list[i]
                               for i in sorted_index_pos]
        pos_euclidian_distance_list = [
            pos_euclidian_distance_list[i] for i in sorted_index_pos]
#        print('train_index_list_epoch', len(train_index_list))
        neg_idx_list = []
        pos_idx_list = []
        for pos_index in local_positive_list:
            if pos_index in train_index_list_ori:
                pos_idx_list.append(pos_index)
        for neg_index in local_negative_list:
            if neg_index in train_index_list_ori:
                neg_idx_list.append(neg_index)
        pos_idx_list = [pos_idx_list[i] for i in range(
            len(pos_idx_list))][:int(topk_pos * len(pos_idx_list))]
        neg_idx_list = [neg_idx_list[i] for i in range(
            len(neg_idx_list))][:int(topk_neg * len(neg_idx_list))]
        # generate list
        for pos_index in pos_idx_list:
            for neg_index in neg_idx_list:

                if pos_index == neg_index or pos_index == anchor_index or neg_index == anchor_index:
                    continue
                anchor_idx_list.append(anchor_index)
                positive_idx_list.append(pos_index)
                negative_idx_list.append(neg_index)
    for i in range(len(anchor_idx_list)):
        assert label[anchor_idx_list[i]] == label[positive_idx_list[i]]
    for i in range(len(anchor_idx_list)):
        assert label[anchor_idx_list[i]] != label[negative_idx_list[i]]
    print('anchor_idx_list:', len(anchor_idx_list))
    print('positive_idx_list:', len(positive_idx_list))
    print('negative_idx_list:', len(negative_idx_list))
    return (torch.tensor(anchor_idx_list), torch.tensor(positive_idx_list),
            torch.tensor(negative_idx_list))
