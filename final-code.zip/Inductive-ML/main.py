import os, torch, logging, argparse
import models
from utils import train, test, val
from data import load_data
from pytorch_metric_learning import losses
import numpy as np
from miner import *
import time
from utils import dic_acc_lable


OUT_PATH = "results/"
if not os.path.isdir(OUT_PATH):
    os.mkdir(OUT_PATH)

# parser for hyperparameters
parser = argparse.ArgumentParser()
parser.add_argument('--data', type=str, default='cora', help='{cora, pubmed, citeseer}.')
parser.add_argument('--model', type=str, default='GCN', help='{SGC, DeepGCN, DeepGAT}')
parser.add_argument('--hid', type=int, default=64, help='Number of hidden units.')
parser.add_argument('--lr', type=float, default=0.005, help='Initial learning rate.')
parser.add_argument('--nhead', type=int, default=1, help='Number of head attentions.')
parser.add_argument('--dropout', type=float, default=0.6, help='Dropout rate.')
parser.add_argument('--epochs', type=int, default=1500, help='Number of epochs to train.')
parser.add_argument('--log', type=str, default='debug', help='{info, debug}')
parser.add_argument('--wd', type=float, default=5e-4, help='Weight decay (L2 loss on parameters).')
# for deep model
parser.add_argument('--nlayer', type=int, default=2, help='Number of layers, works for Deep model.')
parser.add_argument('--residual', type=int, default=0, help='Residual connection')
# for PairNorm
# - PairNorm mode, use PN-SI or PN-SCS for GCN and GAT. With more than 5 layers get lots improvement.
parser.add_argument('--norm_mode', type=str, default='None', help='Mode for PairNorm, {None, PN, PN-SI, PN-SCS}')
parser.add_argument('--norm_scale', type=float, default=1.0, help='Row-normalization scale')
# for data
parser.add_argument('--no_fea_norm', action='store_false', default=True, help='not normalize feature' )
parser.add_argument('--missing_rate', type=int, default=0, help='missing rate, from 0 to 100' )
parser.add_argument('--topk_neg', type=float, default=0.1, help='negtive nodes select, from 0 to 1' )
parser.add_argument('--topk_pos', type=float, default=0.1, help='positive nodes select, from 0 to 1' )
parser.add_argument('--topn', type=float, default=0.1, help='triplet select, from 0 to 1' )
parser.add_argument('--anchor_sample_ratio', type=float, default=0.3, help='anchor nodes select, from 0 to 1' )
parser.add_argument('--miner', type=int, default=1, help='mining mode select, 1:exp miner, 2:softmax miner' )
parser.add_argument('--margin', type=float, default=0.2, help='margin' )


args = parser.parse_args()

# logger
#filename='example.log'
logging.basicConfig(format='%(message)s', level=getattr(logging, args.log.upper())) 

# load data
# data = load_data(args.data, normalize_feature=args.no_fea_norm, missing_rate=args.missing_rate, cuda=True)
train_data, val_data, test_data = load_data(args.data, normalize_feature=args.no_fea_norm, missing_rate=args.missing_rate, cuda=False)
nfeat = train_data.x.size(1)
nclass = int(train_data.y.max()) + 1
# nfeat = data.x.size(1)
# nclass = int(data.y.max()) + 1

#print(int(data.y.max()))
#print(int(data.y.min()))
#print('nclass:',nclass)
net = getattr(models, args.model)(nfeat, args.hid, nclass, 
                                  dropout=args.dropout, 
                                  nhead=args.nhead,
                                  nlayer=args.nlayer, 
                                  norm_mode=args.norm_mode,
                                  norm_scale=args.norm_scale,
                                  residual=args.residual)


# hard_pairs = triple_mining(data,0.8)
print('train_data_x:',train_data.x)

tt = time.time()
hard_pairs = triple_mining(train_data ,
                           topk_neg=args.topk_neg, 
                           topk_pos=args.topk_pos, 
                           anchor_sample_ratio=args.anchor_sample_ratio, 
                           miner=args.miner)
print('hard pairs time:    ', time.time()-tt)


# net = net.cuda()
optimizer = torch.optim.Adam(net.parameters(), args.lr, weight_decay=args.wd)
# miner_or = miners.TripletMarginMiner(margin=args.margin, type_of_triplets="hard")
#hard_pairs = miner_or(train_data.x, train_data.y)
#print('hard_pairs1:',hard_pairs1)
criterion1 = losses.TripletMarginLoss(margin=args.margin)
criterion2 = torch.nn.CrossEntropyLoss()
logging.info(net)

print('graph_miner_size:',len(hard_pairs[0]))

# train
best_acc = 0 
best_loss = 1e10
for epoch in range(args.epochs):
    t = time.time()
    max_epoch = range(args.epochs)[-1]
    #print(max_epoch)
    #with out own miners

#    train_loss, train_acc = train(net, optimizer, criterion1, criterion2, train_data, miner_or, epoch, max_epoch, topn=args.topn, margin=args.margin)    
    train_loss, train_acc, macrof1_train, gmean_train = train(net, optimizer, criterion1, train_data, epoch, max_epoch, hard_pairs)
    #with original miners
    #train_loss, train_acc = train(net, optimizer, criterion1, criterion2, data, miner, epoch, max_epoch)
    #train_loss, train_acc = train(net, optimizer, criterion, data)
    val_loss, val_acc, val_microf1, val_macrof2 = val(net,criterion2 ,val_data)
    logging.debug('Epoch %d: train loss %.3f train acc: %.3f, val loss: %.3f val acc %.3f.' %
                  (epoch, train_loss, train_acc, val_loss, val_acc))
    # save model 
    if best_acc < val_acc:
        best_acc = val_acc
        torch.save(net.state_dict(), OUT_PATH+'checkpoint-best-acc.pkl')
    if best_loss > val_loss:
        best_loss = val_loss
        torch.save(net.state_dict(), OUT_PATH+'checkpoint-best-loss.pkl')
    print('epoch time:    ', time.time()-t)

# pick up the best model based on val_acc, then do test

net.load_state_dict(torch.load(OUT_PATH+'checkpoint-best-acc.pkl'))
#val_loss, val_acc = val(net,criterion2 ,val_data)
test_loss, test_acc, macrof1_test, gmean_test = test(net, criterion2, test_data)
#test_loss, test_acc = test(net,criterion2 ,test_data, nlayer = args.nlayer, data_name=args.data, model_name=args.model)

logging.info("-"*50)
#logging.info("Vali set results: loss %.3f, acc %.3f."%(val_loss, val_acc))
logging.info("Test set results: loss %.3f, acc %.3f."%(test_loss, test_acc))
logging.info("="*50)

def labelList(data):
    label_list = data.y
    # print('type(label_list):  ', type(label_list))

    dic_label = dict()    # {lable:category counts}
    for i, e in enumerate(label_list):
        if label_list[i].item() in dic_label:
            dic_label[label_list[i].item()] += 1
        else:
            dic_label[label_list[i].item()] = 1

    return dic_label

dic_label = labelList(test_data)

dic_acc, dic_lable, lables, preds = dic_acc_lable(net, test_data)

s = 0
for i in dic_lable:
    if i in dic_acc:
        dic_acc[i] = dic_acc[i]/dic_lable[i]
        s+=dic_acc[i]

print('*'*25)
print('dic_acc_lable:  ', dic_acc)
print('dic_label:  ', dic_label)

ss = 0
t = 0
dic = sorted(dic_label.items(),key = lambda x:x[1], reverse = True)
for i in range(len(dic_label)//2, len(dic_label)):
    t += 1
    if dic[i][0] in dic_acc:
        ss += dic_acc[dic[i][0]]
    
tail_ave_acc = ss/t
ave_acc_test = sum(dic_acc.values())/len(dic_label)

logging.info("="*50)
logging.info("Test set results: loss %.3f, acc %.3f, macrof1_test %.3f, gmean_test %.3f, tail_ave_acc %.3f, ave_acc_test %.3f." % (test_loss, test_acc, macrof1_test, gmean_test, tail_ave_acc, ave_acc_test))
logging.info("="*50)