import os
import torch
import logging
import argparse
import models
from utils import train, test, val
from data import load_data
# from pytorch_metric_learning import miners, losses
import numpy as np
from miner import *
import random
import time
from collections import Counter
from utils import dic_acc_lable

OUT_PATH = "results/"
if not os.path.isdir(OUT_PATH):
    os.mkdir(OUT_PATH)

# parser for hyperparameters
parser = argparse.ArgumentParser()
parser.add_argument('--data', type=str, default='cora',
                    help='{cora, pubmed, citeseer}.')
parser.add_argument('--model', type=str, default='GCN',
                    help='{SGC, DeepGCN, DeepGAT}')
parser.add_argument('--hid', type=int, default=64,
                    help='Number of hidden units.')
parser.add_argument('--lr', type=float, default=0.005,
                    help='Initial learning rate.')
parser.add_argument('--nhead', type=int, default=1,
                    help='Number of head attentions.')
parser.add_argument('--dropout', type=float, default=0.6, help='Dropout rate.')
parser.add_argument('--epochs', type=int, default=600,
                    help='Number of epochs to train.')
parser.add_argument('--log', type=str, default='debug', help='{info, debug}')
parser.add_argument('--wd', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
# for deep model
parser.add_argument('--nlayer', type=int, default=2,
                    help='Number of layers, works for Deep model.')
parser.add_argument('--residual', type=int, default=0,
                    help='Residual connection')
# for PairNorm
# - PairNorm mode, use PN-SI or PN-SCS for GCN and GAT. With more than 5 layers get lots improvement.
parser.add_argument('--norm_mode', type=str, default='None',
                    help='Mode for PairNorm, {None, PN, PN-SI, PN-SCS}')
parser.add_argument('--norm_scale', type=float, default=1.0,
                    help='Row-normalization scale')
# for data
parser.add_argument('--no_fea_norm', action='store_false',
                    default=True, help='not normalize feature')
parser.add_argument('--missing_rate', type=int, default=0,
                    help='missing rate, from 0 to 100')
parser.add_argument('--topk_neg', type=float, default=0.1,
                    help='negtive nodes select, from 0 to 1')
parser.add_argument('--topk_pos', type=float, default=0.1,
                    help='positive nodes select, from 0 to 1')
parser.add_argument('--topn', type=float, default=1,
                    help='triplet select, from 0 to 1')
parser.add_argument('--anchor_sample_ratio', type=float,
                    default=0.1, help='anchor nodes select, from 0 to 1')
parser.add_argument('--miner', type=int, default=1,
                    help='mining mode select, 1:exp miner, 2:softmax miner')
parser.add_argument('--margin', type=float, default=0.2, help='margin')

parser.add_argument('--mode', type=float, default=1,
                    help='uni+class 1 or uni+class-node 2')
parser.add_argument('--sample_ratio', type=float,
                    default=0.6, help='0.6--0.8--0.9--1.0')
parser.add_argument('--alpha', type=float, default=0.5, help='0.25--0.5--0.75')

args = parser.parse_args()

# logger
# filename='example.log'
logging.basicConfig(format='%(message)s',
                    level=getattr(logging, args.log.upper()))

# load data
train_data, val_data, test_data = load_data(
    args.data, normalize_feature=args.no_fea_norm, missing_rate=args.missing_rate, cuda=False)

nfeat = train_data.x.size(1)
nclass = int(train_data.y.max()) + 1

net = getattr(models, args.model)(nfeat, args.hid, nclass,
                                  dropout=args.dropout,
                                  nhead=args.nhead,
                                  nlayer=args.nlayer,
                                  norm_mode=args.norm_mode,
                                  norm_scale=args.norm_scale,
                                  residual=args.residual)

label = train_data.y
# net = net.cuda()
optimizer = torch.optim.Adam(net.parameters(), args.lr, weight_decay=args.wd)
criterion2 = torch.nn.CrossEntropyLoss()

logging.info(net)

# train
best_microf1 = 0
best_loss = 1e10


def euclidian_distance(x, y):
    return torch.sqrt(torch.sum((x - y) ** 2))


def anchor_pointcal_(data):
    label = data.y
    adj = data.adj
    train_index_list = list(range(len(data.y)))

    anchor_label_list = []
    anchor_index_list = []
    for anchor_index in train_index_list:
        anchor_index_list.append(anchor_index)
        anchor_label_list.append(int(label[anchor_index].cpu().numpy()))

    traindata_hardpoint_list = []
    for anchor_node in anchor_index_list:
        subanchor_label_list = []
        # get every anchor-node's 1-neighbor
        indices_1 = adj[anchor_node]._indices()

        indices_list_all = list(indices_1.cpu().numpy()[0])
        indices_list_all = list(set(indices_list_all))
        for node in indices_list_all:
            subanchor_label_list.append(int(label[node].cpu().numpy()))
        data_summery = [subanchor_label_list.count(
            i) for i in range(int(data.y.max()) + 1)]
        data_summery = torch.Tensor(data_summery)
        data_summery_ideal = torch.Tensor(
            len(indices_list_all) * np.eye(1, int(data.y.max()) + 1, label[anchor_node])[0])
        numerator = euclidian_distance(data_summery, data_summery_ideal)
        denominator = 2 * euclidian_distance(data_summery_ideal, 0)
        hard_point = numerator / denominator
        traindata_hardpoint_list.append(hard_point)
    return traindata_hardpoint_list


traindata_hardpoint_list = anchor_pointcal_(train_data)

for epoch in range(args.epochs):
    start_time = time.time()
    max_epoch = range(args.epochs)[-1]

    # with out own miners
    train_loss, train_acc, macrof1_train, gmean_train = train(
        net, optimizer, train_data, epoch, max_epoch, criterion2, args.sample_ratio, args.mode, traindata_hardpoint_list)
    val_loss, val_acc, val_microf1, val_macrof2 = val(
        net, val_data, criterion2, args.alpha)
    logging.debug('Epoch %d: train loss %.3f train acc: %.3f, val loss: %.3f val acc %.3f.' %
                  (epoch, train_loss, train_acc, val_loss, val_acc))
    
    if best_microf1 < val_microf1:
        best_microf1 = val_microf1
        torch.save(net.state_dict(), OUT_PATH+'checkpoint-best-acc.pkl')
    if best_loss > val_loss:
        best_loss = val_loss
        torch.save(net.state_dict(), OUT_PATH+'checkpoint-best-loss.pkl')
    print('time:  ', time.time()-start_time)

# pick up the best model based on val_acc, then do test

net.load_state_dict(torch.load(OUT_PATH+'checkpoint-best-acc.pkl'))
test_loss, test_acc, macrof1_test, gmean_test = test(
    net, test_data, criterion2, args.alpha)

logging.info("-"*50)
logging.info("Test set results: loss %.3f, acc %.3f, macrof1_test %.3f, gmean_test %.3f." % (test_loss, test_acc, macrof1_test, gmean_test))
logging.info("="*50)

def labelList(data):
    label_list = data.y
    # print('type(label_list):  ', type(label_list))

    dic_label = dict()    # {lable:category counts}
    for i, e in enumerate(label_list):
        if label_list[i].item() in dic_label:
            dic_label[label_list[i].item()] += 1
        else:
            dic_label[label_list[i].item()] = 1

    return dic_label

dic_label = labelList(test_data)

dic_acc, dic_lable, lables, preds = dic_acc_lable(net, test_data)
# npy_lables=np.array(lables)
# np.save(str(args.data)+'__labels.npy', npy_lables) # 保存为.npy格式
# npy_preds=np.array(preds)
# np.save(str(args.data)+'__preds.npy', npy_preds) # 保存为.npy格式

s = 0
for i in dic_lable:
    if i in dic_acc:
        dic_acc[i] = dic_acc[i]/dic_lable[i]
        s+=dic_acc[i]

# print('s:  ', s)
# ave_acc_test = s/len(dic_acc)
# print('ave_acc_per_class:  ', ave_acc_test)
print('*'*25)
print('dic_acc_lable:  ', dic_acc)
print('dic_label:  ', dic_label)

ss = 0
t = 0
dic = sorted(dic_label.items(),key = lambda x:x[1], reverse = True)
for i in range(len(dic_label)//2, len(dic_label)):
    t += 1
    if dic[i][0] in dic_acc:
        ss += dic_acc[dic[i][0]]
    
tail_ave_acc = ss/t
ave_acc_test = sum(dic_acc.values())/len(dic_label)

logging.info("="*50)
logging.info("Test set results: loss %.3f, acc %.3f, macrof1_test %.3f, gmean_test %.3f, tail_ave_acc %.3f, ave_acc_test %.3f." % (test_loss, test_acc, macrof1_test, gmean_test, tail_ave_acc, ave_acc_test))
logging.info("="*50)